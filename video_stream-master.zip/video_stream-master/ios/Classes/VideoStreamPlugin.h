#import <Flutter/Flutter.h>

@interface VideoStreamPlugin : NSObject<FlutterPlugin>
@end
