package com.marshalltechnology.video_stream_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
